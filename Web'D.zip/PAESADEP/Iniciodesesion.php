<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <STYLE>A {text-decoration: none;} </STYLE>
    
    <link rel="stylesheet" href="css/Sesion.css">
    
    <title>Inicio de sesión</title>
</head>
<body>
  <a  href="Inicio.html"><img class="photo" src="imagenes/vaca.png"/></a>
  <div class="nav">
    <input type="checkbox">
      <span></span>
      <span></span>
      <div class="menu">
            <li><a href="Registro.php">Registro</a></li>
            <li><a href="Iniciodesesion.php">Iniciar Sesión</a></li>
            <li><a href="#">Contactanos</a></li>
        </div>
    </div>
      <div class="contenido-inicio">
          <div class="informacion-inicio">
            <h1 class="titulo">Iniciar sesión</h1>
            <form class="inputs-container">
                <input class="input" type="email" placeholder="Correo">
                <input class="input" type="password" placeholder="Contraseña">
                    <select class="input" name="menu" placeholder="Servicio"> 
                        <option>Estudiante</option>
                        <option>Administrador</option>
                    </select>
                <p>¿olvidaste tu clave? <a class="span" href="Contraseña.html">unde aqui</span></p>
                <button class="botones">Ingresar</button>
                <p>¿Aún no tienes cuenta? <a class="span" href="Registro.html">Registrarse</a></p>
            </form>
          </div>
            <img class="image-container" src="imagenes/vacabaila.gif" alt="" >  
         </div>
</body>
</html>
<!--(text-decoration:none;)-->>