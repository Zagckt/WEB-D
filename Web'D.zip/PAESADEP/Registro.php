<?php
    include "conexion.php";

    if (isset($_POST["registrarse"])){
        $nombres = $_POST["nombres"];
        $apellidos = $_POST["apellidos"];
        $correo = $_POST["correo"];
        $jordana = $_POST["jornada"];
        $grupo = $_POST["grupo"];
        $servicio = $_POST["servicio"];
        $justificacion = $_POST["justificacion"];

        $consulta = "INSERT INTO registro (correo, nombres, apellidos, jornada, grupo, servicio, justificacion) VALUES ('$correo', '$nombres', '$apellidos', '$jordana', '$grupo', '$servicio', '$justificacion')";

        if($con->query($consulta)){
            echo "¡Tu solicitud ha sido enviada exitosamente!";
        }else{
            echo "Lo sentimos, no pudimos generar tu registro, intenta más tarde";
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="css/Registro.css">
    
    <title>Registro</title>
</head>
<body>
    <a  href="Inicio.html"><img class="photo" src="imagenes/vaca.png"/></a>
    <div class="nav">
        <input type="checkbox">
          <span></span>
          <span></span>
          <div class="menu">
                <li><a href="Registro.php">Registro</a></li>
                <li><a href="Iniciodesesion.php">Iniciar Sesión</a></li>
                <li><a href="#">Contactanos</a></li>

            </div>
    </div>
    <br><br>       
      <div class="contenido-inicio">
          <div class="informacion-inicio">
            <h1 class="titulo">Registro</h1>
            <form action="Registro.php" class="inputs-container" method="post">
                <input class="input" type="text" placeholder="Nombres" name="nombres">
				<br>
                <input class="input" type="text" placeholder="Apellidos" name="apellidos">
				<br>
				<input class="input" type="email" placeholder="Correo" name="correo">
				<br>
				<input class="input" type="text" placeholder="Jornada" name="jornada">
				<br>
				<input class="input" type="number" placeholder="Grupo" name="grupo">
				<br>
                <select class="input" name="servicio" placeholder="Servicio" name="servicio"> 
                    <option>Restaurante</option>
                    <option>Vaso de leche</option>

                </select>
                <br>
				<input class="input" type="text" placeholder="Justificación" name="justificacion">
				<br>
                <button class="botones" name="registrarse">Registrarse</button>
            </form>
          </div>
      </div>
    <footer>
    </footer>
</body>
</html>